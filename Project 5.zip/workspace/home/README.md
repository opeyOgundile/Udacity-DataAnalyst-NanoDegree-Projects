# (Bike Sales Dataset Exploration)

## by (Opeyemi Ogundile)


## Dataset

> The dataset containing bike sales. The dataset was gotten from Kaggle (https://www.kaggle.com/datasets/sadiqshah/bike-sales-in-europe)
> The dataset consist of 113,036 rows and 18 columns. After checking for duplicate it was discovered that there are 1000 duplicated values. After removing it became 112,036 rows and 18 columns.They consist of 10 quantitative variables namely: Day, Year, Customer_Age,Order Quantity, Unit_Cost, Unit_price, Profit, Cost and Revenue and Categorical variables namely gender, state, country, products,Product_Category, Sub_Category and month.


## Summary of Findings

> After investigating the datset the following are my findings.
.1. More sales were made in years 2014 and 216,
.2. Adult (35-64) happens to be bringing in more sales.
.3. Most sales happens to come from the United States.
.4. Califonia has most sales by States
.5. Water bottle top the list of sales for Bike Products
.6. Male customers brought it more revenue
.7. July with higehest profit made
.8. Male customers domiates all the age groups. Male customers bought more Acccessories, Clothing and Bikes. Also, Young Adulst (25-34) bought more Accessories, Clothing and Bikes
.9. This indicates a positive correlation. Meaning that the higer the revenue the higher the profit made
.10. It shows a weak corelation between the Age of customer and the revenue.

## Key Insights for Presentation

> I have selected few plots for my presentation.The plots depicts the key variables such as Revenue, Profit, Cost, Customer Age, Age group, Country of Customers, and relationship between some variables. 


